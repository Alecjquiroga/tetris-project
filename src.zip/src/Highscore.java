import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.Scanner;



/**
 * this class takes the highscore form 
 * the game class and saves it to file
 * @author Alec
 *
 */
public class Highscore {
	
	
	/**
	 * this writes the 
	 * @param score from the game class
	 * @throws IOException
	 */
	public void writeHighScore(long score) throws IOException {
		File file = new File("HighScore.txt");
		FileWriter fw = new FileWriter(file, false);
		PrintWriter output = new PrintWriter(fw);
		String highScore = Long.toString(score);
		output.println(highScore);
	}
	
	
	/**
	 * this reads the file
	 * @return the last high score
	 * @throws IOException
	 */
	public long readsFile() throws IOException {
		File file = new File("HighScore.txt");
		Scanner inputfile = new Scanner(file);
		
		String line = inputfile.nextLine();
		long highScore = Long.parseLong(line);
		return highScore;
		
	}
	
}
